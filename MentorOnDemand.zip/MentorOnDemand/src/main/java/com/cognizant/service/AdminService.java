package com.cognizant.service;

import org.springframework.stereotype.Service;

import com.cognizant.entity.PaymentDetails;
import com.cognizant.entity.Technologies;

@Service
public interface AdminService {
	
	Technologies save(Technologies technology);

	void deleteByTechnologyId(long technologyId);

	Iterable<PaymentDetails> findAll();

	
}
