package com.cognizant.service;

import org.springframework.stereotype.Service;

import com.cognizant.dao.AdminDao;
import com.cognizant.dao.MentorDao;
import com.cognizant.dao.PaymentDao;
import com.cognizant.entity.Mentor;
import com.cognizant.entity.PaymentDetails;
import com.cognizant.entity.Technologies;

import org.springframework.beans.factory.annotation.Autowired;
@Service
public class AdminServiceImpl implements AdminService
{
 
	@Autowired
	private AdminDao adminDao;
	@Autowired
	private MentorDao mentorDao;
	@Autowired
	private PaymentDao paymentDao;

	@Override
	public Technologies save(Technologies technologies) 
	{
		return adminDao.save(technologies);
	}

	@Override
	public void deleteByTechnologyId(long technologyId) 
	{
		adminDao.deleteByTechnologyId(technologyId);
	}

	@Override
	public Iterable<PaymentDetails> findAll() {
		 return paymentDao.findAll();
	}

	

	
}
